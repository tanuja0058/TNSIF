/*fullName="Tony Stark";
age = 29;
console.log(age);
console.log(fullName);
console.log("Hello JS");
//second part how to create obj and how to acces 
const student={
    name:"tanuja",
    age: 20,
    cgpa: 9.2,
    ispass: true,
};
//we can change the value using following method
    student["name"]="Shubham";
    student["age"]= student["age"]+1;    
    console.log(student.age);
        console.log(student.name);
        console.log(student["ispass"]);
    
/*Real time example store the insta profile in object
const profile= {
    Username: "TanujaMahajan",
    isFollow: false,
    followers : 123,
    following: 456,
    Bio: "i am student",
}; */ 

//Lecture 2: Operators
/*Arithmatic
let a = 5;
let b = 4;
console.log(a+b);
console.log(a-b);
console.log(a*b);
console.log(a/b);
console.log(a%b);
console.log(a**b);

  */
 //Unary oprator 
 ////let a = 9;
 //let b = 7;
 /*console.log(a++);
 console.log(a--);
 console.log(--a);
 console.log(++a);    
 */
//Assignment Operotor
/*a += 9;
b -= 100;
a *= 40;
a /= 8;
b %= 9;
console.log(a);
console.log(b);*/
//comparison operator
/*console.log(a==b);
console.log(a !=b);
console.log( a ===b);*/

//logical operator
/*let con1 = a>b;
let con2 = a===b;
console.log(con1 && con2);
console.log(con1 || con2);
console.log(!(con2));*/

//*****Ternary Operator *
// let age = 19;
// let result = age>18?"adult":"Not Adult";
// console.log(result);
//Conditonal statements in JS
//IF statement
//let age = 10;
// if(age>=18) {
//    console.log("You Can Vote");
//  }
// if(age<18){
//     console.log("cannot vote");
// }
 //2.IFELSE
//  else{
//     console.log("you cannot vote");
//  }

//First Program for oddeven
// let num = 10;
// if(num % 2==0){
//     console.log(num,"Number is Even");
// }
// else{
//     console.log(num,"number is odd");
// }
 //if=else statement
//  let mode ="dark";
//  let color;
//  if(mode === "dark"){
//     color = "black";
//  }
//  else if (mode=== "pink"){
//     color = "pink";
//  }
//  else if(mode === "white"){
//     color == "White";
//  }
// else{

//     color = "WHite BY Default";
// }
// console.log(color);

//SWITCH Statement
/*
const exp = "Oranges";
switch(exp){
    case 'Oranges':
    console.log('Oranges are 10Rs');
    break;
    case 'Chikoo':
    case 'amba':
        console.log("amba and orange 20rs");
    break;
    default:
        console.log('doesnt match ${exp}');

}*/
 //**** BOXES****
// alert("Hello");
// let a = prompt("hello");
// console.log(a);

// let num = prompt("Enter  the Number");
// if(num % 5==0){
//     console.log("5 is multiple of",num);
// }
// else{
//     console.log("Not multiple of 5",num);
// }

//Lecture 3: Loops In JS
//For loop
// let sum = 0;
// let n = 100
// for(let i = 1; i<=n; i++){
//  sum = sum + i;
// }
//  console.log("sum=",sum);

//while loop
// let i = 1;
// while(i<=5){
//     console.log("I am While loop");
//     i++;
// }

//DO=while
// let i = 10;
// do{
//     console.log(i);
//     i++;
// }while(i<=10);

//for-of loop
// let str = "Tanuja";
// //how to ccalculate str len
// let size=0;

// for (let i of str){
//     console.log(i);
//     size++;
// }
// console.log(size);